package colors

// Reset ascii code
const Reset = "\033[0m"

// Red ascii code
const Red = "\033[31m"

// Green ascii code
const Green = "\033[32m"

// Yellow ascii code
const Yellow = "\033[33m"

// Blue ascii code
const Blue = "\033[34m"

// Purple ascii code
const Purple = "\033[35m"

// Cyan ascii code
const Cyan = "\033[36m"

// Gray ascii code
const Gray = "\033[37m"

// White ascii code
const White = "\033[97m"
